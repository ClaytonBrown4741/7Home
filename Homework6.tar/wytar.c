/*
* wytar.c
* Author: Clayton Brown
* Date: Feb 18, 2023
*
* COSC 3750, Homework 6
*
* This is an altered version of the tar utility
* It is capable of either extracting or compiling
* tar files when dealing with regular files, links
* and directories
*
*/

#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include<dirent.h>
#include<errno.h>
#include<tar.h> // for some macros
#include<grp.h>
#include<pwd.h>

#include"tar_header.h"

int main(int argc, char **argv, char **envp){
  // This is used to check for completed function calls
  int checker=0;
  int testChecker=0;

  if (argc < 3){
    fprintf(stderr, "Not enough arguments to operate.\n");
    return 1;
  }
  
  if (strcmp(argv[1], "-c")!=0 && strcmp(argv[1], "-x")!=0){
    fprintf(stderr, "Cannot Operate, Missing -c or -x argument.\n");
    return 1;
  }


  if (strcmp(argv[2], "-f")!=0){
    fprintf(stderr, "Cannot Operate, Missing -f argument.\n");
    return 1;
  }


  // If the -c option is enabled, call printTarEntry function on
  // all of the given files
  if (strcmp(argv[1], "-c")==0){
    FILE *fileptr=NULL;
    char endingBlock[1024];
    
    // Resets the tar file, if necessary
    fileptr=fopen(argv[3], "w");
    if (fileptr==NULL){
      fprintf(stderr, "Error: Cannot open given tar file.\n");
      return 1;
    }

    testChecker=fclose(fileptr);
    if (testChecker!=0){
      fprintf(stderr, "Error: Could not close given tar file.\n");
      return 1;
    }

    for (int i=4; i<argc; i++){
      checker=printTarEntry(argv[i], argv[3]);
      if (checker!=1){
        fprintf(stderr, "Wytar has quit running.\n");
        return 1;
      }
    }
    
    // Once done with the file, put the ending block
    strncpy(endingBlock, "", 1024);
    fileptr=fopen(argv[3], "a");
    if (fileptr==NULL){
      fprintf(stderr, "Error: Cannot open given tar file.\n");
      return 1;
    }
    testChecker=fwrite(endingBlock, 1, 1024, fileptr);
      if(testChecker!=1024){
        fprintf(stderr, "Error: Final blocks not written to file.\n");
      }
    testChecker=fclose(fileptr);
    if (testChecker!=0){
      fprintf(stderr, "Error: Could not close given tar file.\n");
      return 1;
    }

  }

  // If the -x option is enabled then call the readTarInfo function
  // on the given tar file
  else if (strcmp(argv[1], "-x")==0){
    checker = readTarInfo(argv[3]);
    if (checker!=1){
      fprintf(stderr, "Wytar has quit running.\n");
      return 1;
    }
  }
}
